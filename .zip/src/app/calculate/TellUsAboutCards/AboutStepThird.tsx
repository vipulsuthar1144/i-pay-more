import React, { useState } from "react";

export default function AboutStepThird({
  details,
  updateDetails,
  handleContinue,
  handleBack, // Added handleBack prop for navigation
}: any) {
  const [selectedIssues, setSelectedIssues] = useState(details.functionalProblem || []);
  const options = [
    {
      key: "frontCamera",
      label: "Front Camera not working",
      image: "/path/to/front-camera-icon.svg",
    },
    {
      key: "backCamera",
      label: "Back Camera not working",
      image: "/path/to/back-camera-icon.svg",
    },
    {
      key: "volumeButton",
      label: "Volume Button not working",
      image: "/path/to/volume-button-icon.svg",
    },
    { key: "wifi", label: "WiFi not working", image: "/path/to/wifi-icon.svg" },
    {
      key: "fingerTouch",
      label: "Finger Touch not working",
      image: "/path/to/finger-touch-icon.svg",
    },
    {
      key: "battery",
      label: "Battery in Service (Health is less than 80%)",
      image: "/path/to/battery-icon.svg",
    },
    {
      key: "speaker",
      label: "Speaker Faulty",
      image: "/path/to/speaker-icon.svg",
    },
    {
      key: "chargingPort",
      label: "Charging Port not working",
      image: "/path/to/charging-port-icon.svg",
    },
    {
      key: "powerButton",
      label: "Power Button not working",
      image: "/path/to/power-button-icon.svg",
    },
    {
      key: "faceSensor",
      label: "Face Sensor not working",
      image: "/path/to/face-sensor-icon.svg",
    },
    {
      key: "silentButton",
      label: "Silent Button not working",
      image: "/path/to/silent-button-icon.svg",
    },
    {
      key: "audioReceiver",
      label: "Audio Receiver not working",
      image: "/path/to/audio-receiver-icon.svg",
    },
    {
      key: "cameraGlass",
      label: "Camera Glass Broken",
      image: "/path/to/camera-glass-icon.svg",
    },
    {
      key: "bluetooth",
      label: "Bluetooth not working",
      image: "/path/to/bluetooth-icon.svg",
    },
    {
      key: "vibrator",
      label: "Vibrator is not working",
      image: "/path/to/vibrator-icon.svg",
    },
    {
      key: "microphone",
      label: "Microphone not working",
      image: "/path/to/microphone-icon.svg",
    },
    {
      key: "Proximity Sensor",
      label: "Proximity Sensor is not working",
      image: "/path/to/microphone-icon.svg",
    },
  ];

  const handleSelection = (label: any) => {
    const updatedIssues = selectedIssues.includes(label)
      ? selectedIssues.filter((functionalProblem: any) => functionalProblem !== label) // Deselect
      : [...selectedIssues, label]; // Select

    setSelectedIssues(updatedIssues);
    updateDetails("functionalProblem", updatedIssues); // Save updated issues
  };

  return (
    <div className="rounded-md w-full sm:w-2/3 bg-white shadow-lg p-6 sm:mr-4 sm:min-h-72 flex flex-col">
      <div className="text-center text-xl font-semibold text-gray-800 mb-5">Functional or Physical Problems</div>
      <div className="text-center text-gray-600 mb-4 text-sm">
        Please choose appropriate condition to get accurate quote
      </div>

      {/* Add your step-specific content here */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-5">
        {options.map(({ key, label, image }) => (
          <div
            key={key}
            onClick={() => handleSelection(label)}
            className={`flex flex-col justify-center items-center p-4 border-2 rounded-lg cursor-pointer
          ${selectedIssues.includes(label) ? "border-red-500 bg-red-100" : "border-gray-300 bg-white"}
          transition-colors duration-300 hover:border-red-400 hover:bg-red-50`}
          >
            <div className="w-full flex justify-center items-center mb-3">
              <img src={image} alt={label} className="w-20 h-20 object-contain" />
            </div>

            <div className="text-center text-gray-700 text-sm">{label}</div>
          </div>
        ))}
      </div>

      <div className="flex justify-center gap-5 mt-5">
        <button
          type="button"
          onClick={handleBack} // Navigate to the previous step
          className="py-2 px-6 bg-gray-200 text-gray-700 rounded-lg shadow-md hover:bg-gray-300 transition-colors duration-200"
        >
          Back
        </button>
        <button
          type="button"
          onClick={handleContinue} // Navigate to the next step
          className="py-2 px-6 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 transition-colors duration-200"
        >
          Continue
        </button>
      </div>
    </div>
  );
}
