import ItemImage from "@components/ui/ItemImage";
import React from "react";

export default function DeviceDetails({ userMobileData, details }: any) {
  return (
    <div className="sm:block bg-gray-100 rounded-md w-full sm:w-1/3 shadow-lg flex flex-col p-6">
      <div className="flex flex-row items-center p-4">
        <div className="flex flex-row items-center justify-center h-24">
          <img
            alt={`${userMobileData.modelName}${userMobileData.storage}`}
            className="img-resp h-20 object-cover"
            loading="lazy"
            // fetchpriority="low"
            src={`${userMobileData.modelImage}`}
          />
        </div>
        <div className="body1 pl-5 text-sm text-gray-700">
          {userMobileData.modelName}({userMobileData.storage})
        </div>
      </div>
      <div className="text-lg font-medium text-gray-800 mb-3">Device Evaluation</div>
      <div className="text-xs text-gray-500 mb-2">Device Details</div>
      <ul className="list-disc ml-6 text-xs text-gray-600 space-y-2">
        {details.callFunctionality && (
          <li>
            <span className="font-semibold">Able to Make and Receive Calls:</span> {details.callFunctionality}
          </li>
        )}
        {details.screenOriginal && (
          <li>
            <span className="font-semibold">Screen Original:</span> {details.screenOriginal}
          </li>
        )}
        {details.warranty && (
          <li>
            <span className="font-semibold">Warranty Available:</span> {details.warranty}
          </li>
        )}
        {details.gstBill && (
          <li>
            <span className="font-semibold">GST Bill:</span> {details.gstBill}
          </li>
        )}
        {details.esimSupport && details.esimSupport !== "" && (
          <li>
            <span className="font-semibold">eSIM Support:</span> {details.esimSupport}
          </li>
        )}
        {details.touchScreen && details.touchScreen !== "" && (
          <li>
            <span className="font-semibold">Touch Screen:</span> {details.touchScreen === "Yes" ? "Working" : "Faulty"}
          </li>
        )}
        {details.issues &&
          details.issues.length !== 0 &&
          details.issues.map((issue: any, index: number) => (
            <li key={index} className="">
              {issue}
            </li>
          ))}
      </ul>

      {details.functionalProblem && details.functionalProblem.length > 0 && (
        <div className="text-xs text-gray-500 mb-2 mt-2">Functional Issues</div>
      )}
      <ul className="list-disc ml-6 text-xs text-gray-600 space-y-2">
        {details.functionalProblem &&
          details.functionalProblem.length > 0 &&
          details.functionalProblem.map((issue: any, index: number) => <li key={index}>{issue}</li>)}
      </ul>

      {details.accessories && details.accessories.length > 0 && (
        <div className="text-xs text-gray-500 mb-2 mt-2">Do you have the following?</div>
      )}
      <ul className="list-disc ml-6 text-xs text-gray-600 space-y-2">
        {details.accessories &&
          details.accessories.length > 0 &&
          details.accessories.map((accessories: any, index: number) => <li key={index}>{accessories}</li>)}
      </ul>
    </div>
  );
}
