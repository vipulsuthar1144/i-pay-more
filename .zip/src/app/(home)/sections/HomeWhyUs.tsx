import { Tag, Banknote, Truck, Database, FileText, Hand, IndianRupeeIcon } from "lucide-react";

const features = [
  { icon: Tag, title: "Best Prices", description: "Objective AI-based pricing" },
  {
    icon: IndianRupeeIcon,
    title: "Instant Payment",
    description: "Instant Money Transfer in your preferred mode at time of pick up or store drop off",
  },
  { icon: Truck, title: "Free Doorstep Pickup", description: "No fees for pickup across 1500 cities across India" },
  { icon: Database, title: "Factory Grade Data Wipe", description: "100% Safe and Data Security Guaranteed" },
  { icon: FileText, title: "Valid Purchase Invoice", description: "Genuine Bill of Sale" },
  { icon: Hand, title: "Simple & Convenient", description: "Check price, schedule pickup & get paid" },
];

export default function WhyUs() {
  return (
    <section className="bg-gray-200/50 py-10">
      <div className="container mx-auto px-5 sm:px-0 ">
        <h2 className="text-3xl font-bold mb-6">Why IPM</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map(({ icon: Icon, title, description }, index) => (
            <div key={index} className="flex items-center space-x-4 p-4 rounded-md">
              <div className="min-w-14">
                <Icon size={50} />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-lg">{title}</h3>
                <p className="text-gray-600 text-sm">{description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
