import imgSellHeroSection from "@assets/images/sell/sell-page-banner.png";

export { imgSellHeroSection };
