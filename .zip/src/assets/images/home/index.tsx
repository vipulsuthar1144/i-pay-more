import imgHomeHeroSection from "@assets/images/home/home_hero_section.jpg";
import imgHomeCoverImg from "@assets/images/home/home-cover-img.jpg";
import appLogo from "@assets/images/appLogo.png";
import imgDoubleQuates from "@assets/images/double-quates.webp";

export { imgHomeHeroSection, imgHomeCoverImg, appLogo, imgDoubleQuates };
