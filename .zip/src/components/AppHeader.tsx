"use client";

import useLocalStorage from "@/config/hooks/useLocalStorage.hooks";
import { useAppDispatch } from "@/store";
import { toggleLoginDialogState } from "@/store/slices/auth.slice";
import { appLogo } from "@assets/images/home";
import { LocalStorageKeys } from "@lib/constants";
import Image from "next/image";
import Link from "next/link";

const Header = () => {
  const dispatch = useAppDispatch();
  const [accessToken, __] = useLocalStorage(LocalStorageKeys.ACCESS_TOKEN, "");

  const handleLogin = () => {
    dispatch(toggleLoginDialogState());
  };
  return (
    <>
      <header className="bg-white shadow-md sticky top-0 z-40">
        {/* Top Header */}
        <div className="container mx-auto px-5 sm:px-0  py-3 flex items-center justify-between">
          {/* Logo */}
          <div>
            <Link href="/">
              {/* <Apple className="h-8 w-8 text-gray-900" /> */}
              <Image src={appLogo} alt={"App Logo"} width={50} height={50} className="brightness-0" />
              {/* <span className="ml-2 text-xl font-bold text-gray-900">IPM</span> */}
            </Link>
          </div>
          {/* Search Bar */}
          {/* <div className="hidden md:flex flex-1 mx-6 relative">
            <SearchIcon className="absolute top-2.5 left-2.5 text-gray-700" size={20} />
            <input
              type="text"
              placeholder="Search for services, products, or help..."
              className=" w-full pl-10 pr-4 py-2 border rounded-lg text-gray-700 bg-gray-100 focus:outline-none"
            />
            <X className="absolute top-2 right-3 text-gray-700" size={24} />
          </div> */}
          {/* Login */}
          <div className="flex items-center space-x-4">
            {/* <Link
            href="/login"
            className="bg-blue-600 text-white px-8 py-2 rounded-lg hover:bg-blue-700 text-sm transition duration-300"
          >
            Login
          </Link> */}
            {/* <Profile /> */}

            <button
              onClick={() => {
                handleLogin();
              }}
              className="bg-black text-white py-2 px-6 rounded-lg flex items-center justify-center shadow-md hover:bg-gray-800 transition duration-300"
            >
              {accessToken ? "Logout" : "Login"}
              {/* <span className="ml-2">→</span> */}
            </button>
          </div>
        </div>
      </header>
    </>
  );
};

export default Header;
