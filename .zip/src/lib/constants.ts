export const PRODUCT_TYPES: string[] = ["IPHONES", "IPADS", "MACBOOKS"];

export const LocalStorageKeys = {
  ACCESS_TOKEN: "ACCESS_TOKEN",
  USER_DATA: "USER_DATA",
};
